(function() {
  /**
   * Check and set a global guard variable.
   * If this content script is injected into the same page again,
   * it will do nothing next time.
   */
  if (window.hasRun) {
    return;
  }
  window.hasRun = true;

  /**
   * Given a URL and color create a ribbon and add it to the page.
   */
  function insertRibbon(color, url) {
    removeExistingRibbon();

    let ribbonWrapper = document.createElement('div');
    ribbonWrapper.className = 'ribbon-wrapper';

    let ribbon = document.createElement('div');
    ribbon.setAttribute('style', 'background-color: ' + color + ';');
    ribbon.className = 'ribbon';
    ribbon.textContent = truncateString(url, 10);

    ribbonWrapper.appendChild(ribbon);

    document.body.appendChild(ribbonWrapper);
  }

  function truncateString(str, num) {
    if (str.length <= num) {
      return str
    }
    return str.slice(0, num) + '...'
  }

  /**
   * Remove the ribbon from the page.
   */
  function removeExistingRibbon() {
    let existingRibbons = document.querySelectorAll(".ribbon-wrapper");
    for (let ribbon of existingRibbons) {
      ribbon.remove();
    }
  }

  /**
   * Listen for messages from the background script.
   * Call "addRibbon()" or "reset()".
  */
  browser.runtime.onMessage.addListener((message) => {
    if (message.command === "addRibbon") {
      insertRibbon(message.color, message.url);
    } else if (message.command === "reset") {
      removeExistingRibbon();
    }
  });

})();
