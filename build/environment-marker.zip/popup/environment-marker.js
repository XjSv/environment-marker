/* initialise variables */
let urlInput = document.querySelector('.env-settings #url'),
    colorInput = document.querySelector('.env-settings #color'),
    settingsContainer = document.querySelector('.settings-container'),
    clearBtn = document.querySelector('.clear'),
    saveBtn = document.querySelector('.save');

/* add event listeners to buttons */
saveBtn.addEventListener('click', saveSettings);
clearBtn.addEventListener('click', clearAll);

/* generic error handler */
function onError(error) {
  console.log(error);
}

/* display previously-saved stored notes on startup */
initialize();

function initialize() {
  browser.storage.local.get(null).then((results) => {
    let settingsKeys = Object.keys(results);
    for (let settingUrl of settingsKeys) {
      let settingColor = results[settingUrl];
      displaySetting(settingUrl, settingColor);
    }
  }, onError);
}

/* Add a setting to the display, and storage */
function saveSettings() {
  let settingUrl = urlInput.value,
      settingColor = colorInput.value;

  browser.storage.local.get(settingUrl).then((result) => {
    let objTest = Object.keys(result);
    if (objTest.length < 1 && settingUrl !== '' && settingColor !== '') {
      urlInput.value = '';
      colorInput.value = '';
      storeSetting(settingUrl, settingColor);
    }
  }, onError);
}

/* function to store a new setting in storage */
function storeSetting(settingUrl, settingColor) {
  browser.storage.local.set({ [settingUrl] : settingColor }).then(() => {
    displaySetting(settingUrl, settingColor);
  }, onError);
}

/* function to display a setting in the setting box */
function displaySetting(settingUrl, settingColor) {
  /* create setting display box */
  let setting = document.createElement('div'),
      settingDisplay = document.createElement('div'),
      settingH = document.createElement('div'),
      settingsettingColor = document.createElement('div'),
      deleteBtn = document.createElement('button'),
      clearFix = document.createElement('div');

  settingH.setAttribute('class', 'display-url');
  settingsettingColor.setAttribute('class', 'display-color');
  setting.setAttribute('class', 'setting');

  settingH.textContent = settingUrl;
  settingsettingColor.textContent = settingColor;
  deleteBtn.setAttribute('class', 'delete');
  deleteBtn.textContent = 'Delete';
  clearFix.setAttribute('class', 'clearfix');

  settingDisplay.appendChild(settingH);
  settingDisplay.appendChild(settingsettingColor);
  settingDisplay.appendChild(deleteBtn);
  settingDisplay.appendChild(clearFix);

  setting.appendChild(settingDisplay);

  /* set up listener for the delete functionality */
  deleteBtn.addEventListener('click', (e) => {
    let evtTgt = e.target;
    evtTgt.parentNode.parentNode.parentNode.removeChild(evtTgt.parentNode.parentNode);
    browser.storage.local.remove(settingUrl);
  })

  /* create setting edit box */
  let settingEdit = document.createElement('div'),
      settingUrlEdit = document.createElement('input'),
      settingSettingColorEdit = document.createElement('input'),
      clearFix2 = document.createElement('div'),
      updateBtn = document.createElement('button'),
      cancelBtn = document.createElement('button');

  updateBtn.setAttribute('class', 'update');
  updateBtn.textContent = 'Update';
  cancelBtn.setAttribute('class', 'cancel');
  cancelBtn.textContent = 'Cancel';

  settingEdit.appendChild(settingUrlEdit);
  settingUrlEdit.value = settingUrl;
  settingEdit.appendChild(settingSettingColorEdit);
  settingSettingColorEdit.value = settingColor;
  settingEdit.appendChild(updateBtn);
  settingEdit.appendChild(cancelBtn);

  settingEdit.appendChild(clearFix2);
  clearFix2.setAttribute('class', 'clearfix');

  setting.appendChild(settingEdit);

  settingsContainer.appendChild(setting);
  settingEdit.style.display = 'none';

  /* set up listeners for the update functionality */
  settingH.addEventListener('click', () => {
    settingDisplay.style.display = 'none';
    settingEdit.style.display = 'block';
  })

  settingsettingColor.addEventListener('click', () => {
    settingDisplay.style.display = 'none';
    settingEdit.style.display = 'block';
  })

  cancelBtn.addEventListener('click', () => {
    settingDisplay.style.display = 'block';
    settingEdit.style.display = 'none';
    settingUrlEdit.value = settingUrl;
    settingSettingColorEdit.value = settingColor;
  })

  updateBtn.addEventListener('click', () => {
    if (settingUrlEdit.value !== settingUrl || settingSettingColorEdit.value !== settingColor) {
      updateSetting(settingUrl, settingUrlEdit.value, settingSettingColorEdit.value);
      setting.parentNode.removeChild(setting);
    }
  });
}

/* function to update settings */
function updateSetting(settingUrl, newSettingUrl, settingColor) {
  browser.storage.local.set({ [newSettingUrl] : settingColor }).then(() => {
    if (settingUrl !== newSettingUrl) {
      let removingSetting = browser.storage.local.remove(settingUrl);
      removingSetting.then(() => {
        displaySetting(newSettingUrl, settingColor);
      }, onError);
    } else {
      displaySetting(newSettingUrl, settingColor);
    }
  }, onError);
}

/* Clear all settings from the display/storage */
function clearAll() {
  while (settingsContainer.firstChild) {
      settingsContainer.removeChild(settingsContainer.firstChild);
  }
  browser.storage.local.clear();
}
